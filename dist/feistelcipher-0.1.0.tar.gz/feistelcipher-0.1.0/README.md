# FeistelCipher
Naive implementation of Feistel Cipher using Python
